%DIPMAXASPECT   Undocumented till usefulness proved

% (C) 2006- Michael van Ginkel
% 16 Aug 2006 - Created. I use this in preparation for "print" statements...
%               (Hence to attempt to re-position the window; centering it
%                on the screen is probably the only useful option if that
%                would be desired). Bits and bops nicked from dipgetimage/
%                diptruesize


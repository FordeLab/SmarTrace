%GCLOS   Alias for CLOSING.

function out = gclos(varargin)
out = closing(varargin{:});

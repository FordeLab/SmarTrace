%BLURGAUSS   Alias for GAUSSF.

function out = blurgauss(varargin)
out = gaussf(varargin{:});

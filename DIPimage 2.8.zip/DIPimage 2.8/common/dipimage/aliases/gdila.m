%GDILA   Alias for DILATION.

function out = gdila(varargin)
out = dilation(varargin{:});

%BEROS   Alias for BEROSION.

function out = beros(varargin)
out = berosion(varargin{:});

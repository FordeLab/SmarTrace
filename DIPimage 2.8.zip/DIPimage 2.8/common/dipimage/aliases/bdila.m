%BDILA   Alias for BDILATION.

function out = bdila(varargin)
out = bdilation(varargin{:});

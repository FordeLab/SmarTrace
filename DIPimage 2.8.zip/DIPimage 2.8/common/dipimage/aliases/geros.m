%GEROS   Alias for EROSION.

function out = geros(varargin)
out = erosion(varargin{:});

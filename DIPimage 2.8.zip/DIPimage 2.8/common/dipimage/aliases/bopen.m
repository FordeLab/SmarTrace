%BOPEN   Alias for BOPENING.

function out = bopen(varargin)
out = bopening(varargin{:});

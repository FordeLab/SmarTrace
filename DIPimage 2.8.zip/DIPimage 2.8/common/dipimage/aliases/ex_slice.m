%EX_SLICE   Alias for SLICE_EX

function out = ex_slice(varargin)
out = slice_ex(varargin{:});

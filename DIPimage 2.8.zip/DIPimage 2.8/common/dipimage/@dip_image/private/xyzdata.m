%OUT = XYZDATA

% (C) Copyright 1999-2009               Pattern Recognition Group
%     All rights reserved               Faculty of Applied Physics
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
% Cris Luengo 2009.

function out = xyzdata

out = [0.412453, 0.357580, 0.180423
       0.212671, 0.715160, 0.072169
       0.019334, 0.119193, 0.950227];
   
% inv(out) = [ 3.240479,-1.537150,-0.498535
%             -0.969256, 1.875992, 0.041556
%              0.055648,-0.204043, 1.057311];
